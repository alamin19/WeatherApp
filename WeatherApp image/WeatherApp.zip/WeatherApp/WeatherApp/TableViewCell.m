//
//  TableViewCell.m
//  WeatherApp
//
//  Created by  Al Amin on 3/19/18.
//  Copyright © 2018  Al Amin. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
